'''
DISTRIBUTION STATEMENT F: Further dissemination only as directed by Army Rapid Capabilities Office, or higher DoD authority.
'''
__version__ = '1.2.0'