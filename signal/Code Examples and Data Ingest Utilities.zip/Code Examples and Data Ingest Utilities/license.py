DATA_RIGHTS = (
'''DISTRIBUTION STATEMENT F: Further dissemination only as directed by Army Rapid Capabilities Office, or higher DoD authority.
This software was produced for the U. S. Government under Basic Contract No. W15P7T-13-C-A802, and is subject to the Rights in Noncommercial Computer Software and Noncommercial Computer Software Documentation Clause 252.227-7014 (FEB 2012)
Copyright 2017 The MITRE Corporation. All Rights Reserved.
''') #: